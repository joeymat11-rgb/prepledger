'use strict';
/* INDEPENDENT reviewer challenges for PR47's evidence-applicability helper.
   Written by the reviewer; NOT a rerun of the builder suite. All fixtures are synthetic
   and disposable. Original target/test/expectation bytes are never modified.
   Usage: node challenge.cjs <path-to-review-checkout> */
const fs=require('node:fs'),path=require('node:path'),cp=require('node:child_process'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const CHECKOUT=path.resolve(process.argv[2]);
const E=require(path.join(CHECKOUT,'rebuild/process/evidence-applicability.cjs'));
const scratch=path.join(__dirname,'challenge-scratch');fs.rmSync(scratch,{recursive:true,force:true});fs.mkdirSync(scratch,{recursive:true});
const hash=x=>crypto.createHash('sha256').update(x).digest('hex');
const bytes=x=>Buffer.from(JSON.stringify(x,null,2)+'\n');
const REPORT='rebuild/m2/REPORT-M2-STEP-EFFICACY-ASTRA.md';
const ENVELOPE='rebuild/conform/v4/postfix/manifest-step-efficacy.json';
// A purely synthetic private-canary token. Nothing real; used only to prove that no
// supplied field can reach formatted public output.
const CANARY='SYNTHETIC-PRIVATE-CANARY-9f3a11c7';

function build(o={}){
  const dir=fs.mkdtempSync(path.join(scratch,'fx-'));let n=0;
  const git=a=>cp.execFileSync('git',a,{cwd:dir,encoding:'utf8',stdio:['ignore','pipe','pipe']}).trim();
  const write=(f,b)=>{const p=path.join(dir,f);fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,b);};
  const commit=()=>{git(['add','-A']);git(['-c','user.name=RevSynthetic','-c','user.email=rev@example.invalid','commit','-qm','rev '+n++]);return git(['rev-parse','HEAD']);};
  git(['init','-q']);
  const inputs={};for(const k of E.INPUTS){const f='in/'+k+'.txt',t='rev input '+k+'\n';write(f,t);inputs[k]={[f]:hash(t)};}
  write(REPORT,'rev original report\n');write('rebuild/DECISIONS.md','rev ledger\n');
  const original=commit();
  let successor;
  if(o.merge){git(['checkout','-qb','side']);write(REPORT,'side report\n');commit();git(['checkout','-qb','mainline',original]);write('rebuild/DECISIONS.md','rev ledger combined\n');commit();
    git(['-c','user.name=RevSynthetic','-c','user.email=rev@example.invalid','merge','--no-ff','-qm','rev merge','side']);successor=git(['rev-parse','HEAD']);}
  else{write(REPORT,'rev successor report\n');
    if(o.receiptUpdate)write('rebuild/DECISIONS.md','rev ledger updated\n');
    if(o.outOfScopePath)write(o.outOfScopePath,'out of declared scope\n');
    if(o.diskDrift){const f=Object.keys(inputs[o.diskDrift])[0];write(f,'DISK DRIFT\n');}
    successor=commit();}
  const observations=Object.fromEntries(E.FACTS.map(k=>[k,hash('rev observed '+k)]));
  const evidence={version:1,profile:E.PROFILE,candidate:original,role:'cowork',command:'POSTFIX-M2-STEP-EFFICACY',status:'PASS',exitCode:0,completed:true,
    invocations:E.INVOCATIONS.map(id=>({id,status:'PASS',exitCode:0})),totals:{gateIdentities:19,invocations:28,raw:180,direct:1180,mutants:68},
    inputs:structuredClone(inputs),observations:structuredClone(observations)};
  o.evidence?.(evidence);
  write('ev/original.json',bytes(evidence));const evCommit=commit();
  const record={version:1,profile:E.PROFILE,originalEvidence:{commit:evCommit,file:'ev/original.json',sha256:hash(bytes(evidence))},successor,
    inputs:structuredClone(inputs),currentObservations:structuredClone(observations),
    changedPaths:git(['diff','--name-only',original,successor]).split(/\r?\n/).filter(Boolean),scope:'RECEIPT-REPORT-ONLY',combined:null};
  if(o.combined){
    const result={candidate:successor,role:'integrator',status:'PASS',exitCode:0,checks:['receipt','scope','affected-combined-build'],environment:observations.environment};
    o.combinedResult?.(result);
    const file='ev/combined.json';write(file,bytes(result));const rc=commit();const reference={commit:rc,file,sha256:hash(bytes(result))};
    const line='- rev · integrator · COMBINED-EVIDENCE '+E.PROFILE+' '+rc+' '+file+' '+reference.sha256+' PASS';
    write('rebuild/DECISIONS.md','rev ledger combined\n'+line+'\n');const rb=commit();
    record.combined={reference,receiptBase:rb,receipt:{commit:rb,path:'rebuild/DECISIONS.md',line,lineSha256:hash(line)}};
  }
  o.record?.(record);
  write('ev/applicability.json',bytes(record));const recCommit=commit();
  const recordRef={commit:recCommit,file:'ev/applicability.json',sha256:hash(bytes(record))};
  const role=o.receiptRole||'cowork';
  const line='- rev · '+role+' · EVIDENCE-APPLICABILITY '+E.PROFILE+' '+recCommit+' '+recordRef.file+' '+recordRef.sha256+' ACCEPTED';
  write('rebuild/DECISIONS.md','rev ledger\n'+line+'\n');const reviewBase=commit();
  const receipt={commit:reviewBase,path:'rebuild/DECISIONS.md',line,lineSha256:o.forgeLineSha?hash(line+'x'):hash(line)};
  git(['update-ref','refs/remotes/origin/rebuild/t2-client-core',reviewBase]);
  git(['checkout','-q','--detach',successor]);
  const args={root:dir,reviewBase,receipt,recordRef,successor};o.args?.(args);
  return {dir,git,write,args,run:()=>E.verifyReviewedEvidence(args)};
}
const results=[];
function chk(name,expectStatus,o,after){
  let r;try{const f=build(o);r=after?after(f):f.run();}catch(e){r={status:'THREW',code:String(e.message).slice(0,60)};}
  const ok=expectStatus==='REUSE-ELIGIBLE'?r.status==='REUSE-ELIGIBLE':r.status!=='REUSE-ELIGIBLE';
  results.push({name,expect:expectStatus,got:r.status+'/'+r.code,pass:ok});
}
// ---------- POSITIVE CONTROLS (must be REUSE-ELIGIBLE; proves this is not an always-refuse mutant)
chk('P1 clean receipt/report-only successor','REUSE-ELIGIBLE',{});
chk('P2 ledger-touching successor WITH valid combined checks','REUSE-ELIGIBLE',{receiptUpdate:true,combined:true});
// ---------- SOURCE / TRANSITIVE INPUTS
chk('N1 transitive input drifted on disk only','REFUSE',{diskDrift:'transitive'});
chk('N2 product pin altered in record','REFUSE',{record:r=>{const f=Object.keys(r.inputs.product)[0];r.inputs.product[f]=hash('rewritten');}});
chk('N3 sourceSelection class emptied','REFUSE',{record:r=>{r.inputs.sourceSelection={};}});
chk('N4 dependencies class omitted','REFUSE',{record:r=>{delete r.inputs.dependencies;}});
// ---------- ENVIRONMENT / COMPOSITION
chk('N5 environment observation unavailable (null)','REFUSE',{evidence:e=>{e.observations.environment=null;}});
chk('N6 custody observation changed','REFUSE',{record:r=>{r.currentObservations.custody=hash('different custody');}});
chk('N7 merged composition in successor range','REFUSE',{merge:true});
chk('N8 successor touches an out-of-scope product path','REFUSE',{outOfScopePath:'rebuild/engine/energy.cjs'});
chk('N9 scope relabelled away from RECEIPT-REPORT-ONLY','REFUSE',{record:r=>{r.scope='EDITORIAL';}});
// ---------- FAILED / INCOMPLETE / PENDING EVIDENCE
chk('N10 original run status REVIEW-PENDING','REFUSE',{evidence:e=>{e.status='REVIEW-PENDING';}});
chk('N11 original exitCode non-zero','REFUSE',{evidence:e=>{e.exitCode=2;}});
chk('N12 original completed=false','REFUSE',{evidence:e=>{e.completed=false;}});
chk('N13 one invocation FAILED inside an overall PASS','REFUSE',{evidence:e=>{e.invocations[9]={...e.invocations[9],status:'FAIL',exitCode:1};}});
chk('N14 invocation inventory truncated','REFUSE',{evidence:e=>{e.invocations=e.invocations.slice(0,20);}});
chk('N15 totals inflated','REFUSE',{evidence:e=>{e.totals={...e.totals,mutants:69};}});
// ---------- FORGED ROLE / RECEIPT / ANCHOR
chk('N16 receipt role forged to integrator','REFUSE',{receiptRole:'integrator'});
chk('N17 receipt lineSha256 forged','REFUSE',{forgeLineSha:true});
chk('N18 original executed by a non-cowork role','REFUSE',{evidence:e=>{e.role='astra';}});
chk('N19 receipt withheld entirely','REFUSE',{args:a=>{a.receipt=null;}});
chk('N20 evidence unanchored to trusted integration','REFUSE',{},f=>{f.git(['update-ref','refs/remotes/origin/rebuild/t2-client-core',f.args.successor]);return f.run();});
chk('N21 trusted integration ref absent','REFUSE',{},f=>{f.git(['update-ref','-d','refs/remotes/origin/rebuild/t2-client-core']);return f.run();});
chk('N22 wrong checkout (HEAD != successor)','REFUSE',{},f=>{f.args.successor='0'.repeat(40);return f.run();});
// ---------- COMBINED-CHECK INTEGRITY
chk('N23 ledger-touching successor with NO combined checks','REFUSE',{receiptUpdate:true});
chk('N24 combined claimed when not required','REFUSE',{combined:true});
chk('N25 combined result environment mismatched','REFUSE',{receiptUpdate:true,combined:true,combinedResult:r=>{r.environment=hash('other env');}});
chk('N26 combined result not actually PASS','REFUSE',{receiptUpdate:true,combined:true,combinedResult:r=>{r.status='FAIL';r.exitCode=1;}});
console.log(JSON.stringify(results,null,1));
process.exitCode=results.some(r=>!r.pass)?1:0;
