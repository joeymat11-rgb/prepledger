'use strict';
/* Independent challenges: public-output canary safety, no gate dispatch/mutation,
   and helper-source-origin tamper detection on a DISPOSABLE COPY.
   Usage: node challenge2.cjs <checkout> */
const fs=require('node:fs'),path=require('node:path'),cp=require('node:child_process'),crypto=require('node:crypto');
const CHECKOUT=path.resolve(process.argv[2]);
const E=require(path.join(CHECKOUT,'rebuild/process/evidence-applicability.cjs'));
const CANARY='SYNTHETIC-PRIVATE-CANARY-9f3a11c7';
const out=[];const rec=(n,pass,detail)=>out.push({name:n,pass,detail});

// C1 — no supplied field may reach the formatted public line.
const poisoned=[{profile:CANARY,status:CANARY,code:CANARY},
                {profile:'x',status:'REUSE-ELIGIBLE',code:CANARY},
                {profile:'x',status:'UNKNOWN',code:'/home/user/private/'+CANARY},
                {status:{toString(){return CANARY;}},code:CANARY}];
let leak=false,lines=[];
for(const p of poisoned){const l=E.publicLine(p);lines.push(l);if(String(l).includes(CANARY))leak=true;}
rec('C1 publicLine never echoes a supplied private canary',!leak,lines.join(' | '));

// C2 — the CLI stdout for a real mapping is exactly one fixed-vocabulary line.
const cli=cp.spawnSync(process.execPath,[path.join(CHECKOUT,'rebuild/process/evidence-applicability.cjs'),'--map-d12','--root',CHECKOUT],{encoding:'utf8'});
const okLine=/^D12 EVIDENCE APPLICABILITY (REUSE-ELIGIBLE|REEXECUTE-REQUIRED|UNKNOWN)\n$/.test(cli.stdout);
rec('C2 CLI stdout is one fixed line, exit 2, no stderr detail',okLine&&cli.status===2&&cli.stderr==='',JSON.stringify({stdout:cli.stdout,status:cli.status,stderr:cli.stderr.slice(0,80)}));

// C3 — unrecognised status collapses to UNKNOWN (no invented vocabulary).
rec('C3 unknown status collapses to UNKNOWN',E.publicLine({status:'TOTALLY-FINE'})==='D12 EVIDENCE APPLICABILITY UNKNOWN',E.publicLine({status:'TOTALLY-FINE'}));

// D1 — running the mapping must not mutate the pinned postfix tree or the helper/test bytes.
function snap(dir){const m={};(function walk(d){for(const e of fs.readdirSync(d,{withFileTypes:true})){const p=path.join(d,e.name);
  if(e.isDirectory())walk(p);else m[p]=crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');}})(dir);return m;}
const watch=[path.join(CHECKOUT,'rebuild/conform/v4/postfix'),path.join(CHECKOUT,'rebuild/process')];
const before=watch.map(snap);
E.assessD12({root:CHECKOUT});
const after=watch.map(snap);
const same=JSON.stringify(before)===JSON.stringify(after);
rec('D1 mapping mutates no pinned postfix / process byte',same,same?'identical':'CHANGED');

// D2 — helper exports no gate dispatcher/skipper surface.
const exported=Object.keys(E);
const forbidden=exported.filter(k=>/run(Gate|Package)|dispatch|skip|execute|spawn/i.test(k));
rec('D2 no gate dispatcher/skipper export',forbidden.length===0,'exports: '+exported.join(','));

// D3 — helper source contains no child-process/gate-execution capability.
const src=fs.readFileSync(path.join(CHECKOUT,'rebuild/process/evidence-applicability.cjs'),'utf8');
const spawns=/child_process|execFile|spawnSync|execSync/.test(src);
rec('D3 helper source cannot spawn a gate process',!spawns,spawns?'FOUND child_process':'none');

// Saved BEFORE any copy or tamper, so D5 is a real before/after comparison.
const VICTIM_IN_CHECKOUT=path.join(CHECKOUT,'rebuild/conform/v4/postfix/acceptance.cjs');
const PRE_TAMPER_SHA=crypto.createHash('sha256').update(fs.readFileSync(VICTIM_IN_CHECKOUT)).digest('hex');
// D4 — tampered postfix validator is rejected (DISPOSABLE COPY; original untouched).
const tmp=fs.mkdtempSync(path.join(__dirname,'tamper-'));
try{
  for(const sub of ['rebuild/process','rebuild/conform/v4/postfix','rebuild/m2']){
    fs.cpSync(path.join(CHECKOUT,sub),path.join(tmp,sub),{recursive:true});}
  const T=require(path.join(tmp,'rebuild/process/evidence-applicability.cjs'));
  let clean;try{clean=T.verifyHelperOrigin(CHECKOUT);}catch(e){clean='THREW '+e.applicabilityCode;}
  const victim=path.join(tmp,'rebuild/conform/v4/postfix/acceptance.cjs');
  fs.writeFileSync(victim,fs.readFileSync(victim,'utf8')+'\nmodule.exports.verifyReceipts=()=>true;\n');
  let tampered;try{tampered=T.verifyHelperOrigin(CHECKOUT);}catch(e){tampered='THREW '+e.applicabilityCode;}
  rec('D4 tampered helper-side validator rejected while target stays clean',clean===true&&tampered==='THREW HELPER-SOURCE-ORIGIN',JSON.stringify({clean,tampered}));
  const after5=crypto.createHash('sha256').update(fs.readFileSync(VICTIM_IN_CHECKOUT)).digest('hex');
  rec('D5 original checkout acceptance.cjs byte-identical before/after tamper test',after5===PRE_TAMPER_SHA,
      'pre='+PRE_TAMPER_SHA+' post='+after5+(after5===PRE_TAMPER_SHA?' IDENTICAL':' CHANGED'));
}finally{fs.rmSync(tmp,{recursive:true,force:true});}

// D6 — assessD12 cannot be coerced eligible by supplying a fabricated record/receipt.
const fake={root:CHECKOUT,recordRef:{commit:'a'.repeat(40),file:'x.json',sha256:'b'.repeat(64)},receipt:{commit:'a'.repeat(40),path:'rebuild/DECISIONS.md',line:'x',lineSha256:'c'.repeat(64)}};
const fr=E.assessD12(fake);
rec('D6 fabricated record/receipt never becomes REUSE-ELIGIBLE',fr.status!=='REUSE-ELIGIBLE',fr.status+'/'+fr.code);

for(const r of out)console.log((r.pass?'PASS ':'**FAIL** ')+r.name.padEnd(58)+' :: '+r.detail);
const failed=out.filter(r=>!r.pass).length;
console.log('\nTOTAL '+out.length+'  pass='+(out.length-failed)+'  fail='+failed);
process.exitCode=failed?1:0;
